## ANEXO I

**ANEXO À RESOLUÇÃO DO CONGRESSO NACIONAL Nº 1, DE 2006-CN**

| Comissão permanente | Área temática → subáreas temáticas (agrupadas como no impresso) | Apropriação | Remanejamento | Total |
|---|---|---:|---:|---:|
| CÂMARA DOS DEPUTADOS | | 76 | 76 | 152 |
| Mesa Diretora | Poderes do Estado e Representação → Câmara dos Deputados | 4 | 4 | 8 |
| Agricultura, Pecuária, Abastecimento e Desenvolvimento Rural - CAPADR | Agricultura e Desenvolvimento Agrário → Ministério da Agricultura, Pecuária e Abastecimento; Ministério da Pesca e Aquicultura; Ministério do Desenvolvimento Agrário<br>Integração Nacional e Meio Ambiente → Ministério da Integração Nacional; Ministério do Meio Ambiente | 4 | 4 | 8 |
| Amazônia, Integração Nacional e Desenvolvimento Regional - CAINDR | Fazenda, Desenvolvimento e Turismo → Ministério do Turismo<br>Integração Nacional e Meio Ambiente → Ministério da Integração Nacional; Ministério do Meio Ambiente<br>Justiça e Defesa → Ministério da Justiça | 4 | 4 | 8 |
| Ciência e Tecnologia, Comunicação e Informática - CCTCI | Educação, Cultura, Ciência e Tecnologia e Esporte → Ministério da Ciência, Tecnologia e Inovação<br>Infraestrutura → Ministério das Comunicações<br>Justiça e Defesa → Ministério da Defesa | 4 | 4 | 8 |
| Constituição e Justiça e de Cidadania - CCJC | Justiça e Defesa → Ministério da Justiça<br>Poderes do Estado e Representação → Órgãos do Ministério Público; Órgãos do Poder Judiciário; Presidência da República | 4 | 4 | 8 |
| Defesa do Consumidor - CDC | Fazenda, Desenvolvimento e Turismo → Ministério da Fazenda; Ministério do Desenvolvimento, Indústria e Comércio Exterior<br>Justiça e Defesa → Ministério da Justiça | 4 | 4 | 8 |
| Desenvolvimento Econômico, Indústria e Comércio - CDEIC | Agricultura e Desenvolvimento Agrário → Ministério da Agricultura, Pecuária e Abastecimento<br>Fazenda, Desenvolvimento e Turismo → Ministério da Fazenda; Ministério do Desenvolvimento, Indústria e Comércio Exterior | 4 | 4 | 8 |
| Desenvolvimento Urbano - CDU | Integração Nacional e Meio Ambiente → Ministério da Integração Nacional; Ministério do Meio Ambiente<br>Planejamento e Desenvolvimento Urbano → Ministério das Cidades | 4 | 4 | 8 |
| Direitos Humanos e Minorias - CDHM | Justiça e Defesa → Ministério da Justiça<br>Poderes do Estado e Representação → Presidência da República<br>Trabalho, Previdência e Assistência Social → Ministério do Desenvolvimento Social e Combate à Fome | 4 | 4 | 8 |
| Educação-CE | Educação, Cultura, Ciência e Tecnologia e Esporte → Ministério da Educação; Ministério da Cultura; Ministério da Ciência, Tecnologia e Inovação; Ministério do Esporte<br>Justiça e Defesa → Ministério da Defesa<br>Trabalho, Previdência e Assistência Social → Ministério do Trabalho e Emprego | 3 | 3 | 6 |
| Cultura -CCULT | Educação, Cultura, Ciência e Tecnologia e Esporte → Ministério da Cultura; Ministério da Educação; Ministério da Ciência, Tecnologia e Inovação; Ministério do Esporte<br>Justiça e Defesa → Ministério da Justiça | 3 | 3 | 6 |
| Finanças e Tributação- CFT | Fazenda, Desenvolvimento e Turismo → Ministério da Fazenda<br>Planejamento e Desenvolvimento Urbano → Ministério do Planejamento, Orçamento e Gestão | 3 | 3 | 6 |
| Fiscalização Financeira e Controle - CFFC | Poderes do Estado e Representação → Ministério do Planejamento, Orçamento e Gestão; Presidência da República; Tribunal de Contas da União | 4 | 4 | 8 |
| Legislação Participativa - CLP | *(células de área e subárea em branco no impresso)* | 0 | 0 | 0 |
| Meio Ambiente e Desenvolvimento Sustentável - CMADS | Educação, Cultura, Ciência e Tecnologia e Esporte → Ministério da Ciência, Tecnologia e Inovação<br>Integração Nacional e Meio Ambiente → Ministério do Meio Ambiente | 3 | 3 | 6 |
| Minas e Energia - CME | Educação, Cultura, Ciência e Tecnologia e Esporte → Ministério da Ciência, Tecnologia e Inovação<br>Infraestrutura → Ministério de Minas e Energia<br>Integração Nacional e Meio Ambiente → Ministério do Meio Ambiente | 4 | 4 | 8 |
| Relações Exteriores e de Defesa Nacional - CREDN | Justiça e Defesa → Ministério da Defesa<br>Poderes do Estado e Representação → Ministério das Relações Exteriores | 3 | 3 | 6 |
| Segurança Pública e Combate ao Crime Organizado - CSPCCO | Justiça e Defesa → Ministério da Justiça | 2 | 2 | 4 |
| Seguridade Social e Família - CSSF | Saúde → Ministério da Saúde<br>Trabalho, Previdência e Assistência Social → Ministério da Previdência Social; Ministério do Desenvolvimento Social e Combate à Fome | 4 | 4 | 8 |
| Trabalho, de Administração e Serviço Público - CTASP | Planejamento e Desenvolvimento Urbano → Ministério do Planejamento, Orçamento e Gestão<br>Trabalho, Previdência e Assistência Social → Ministério da Previdência Social; Ministério do Trabalho e Emprego | 4 | 4 | 8 |
| Turismo e Desporto - CTD | Educação, Cultura, Ciência e Tecnologia e Esporte → Ministério do Esporte<br>Fazenda, Desenvolvimento e Turismo → Ministério do Turismo | 3 | 3 | 6 |
| Viação e Transporte - CVT | Infraestrutura → Ministério dos Transportes<br>Justiça e Defesa → Ministério da Defesa<br>Poderes do Estado e Representação → Presidência da República | 4 | 4 | 8 |
| SENADO FEDERAL | | 45 | 45 | 90 |
| Mesa Diretora | Poderes do Estado e Representação → Senado Federal | 4 | 4 | 8 |
| Agricultura e Reforma Agrária - CRA | Agricultura e Desenvolvimento Agrário → Ministério da Agricultura, Pecuária e Abastecimento; Ministério da Pesca e Aquicultura; Ministério do Desenvolvimento Agrário<br>Integração Nacional e Meio Ambiente → Ministério do Meio Ambiente | 4 | 4 | 8 |
| Assuntos Econômicos - CAE | Fazenda, Desenvolvimento e Turismo → Ministério da Fazenda; Ministério do Desenvolvimento, Indústria e Comércio Exterior<br>Planejamento e Desenvolvimento Urbano → Ministério do Planejamento, Orçamento e Gestão | 4 | 4 | 8 |
| Assuntos Sociais -CAS | Saúde → Ministério da Saúde<br>Trabalho, Previdência e Assistência Social → Ministério da Previdência Social; Ministério do Desenvolvimento Social e Combate à Fome | 4 | 4 | 8 |
| Ciência, Tecnologia, Inovação, Comunicação e Informática - CCT | Agricultura e Desenvolvimento Agrário → Ministério da Agricultura, Pecuária e Abastecimento<br>Educação, Cultura, Ciência e Tecnologia e Esporte → Ministério da Ciência, Tecnologia e Inovação; Ministério da Educação<br>Infraestrutura → Ministério das Comunicações<br>Justiça e Defesa → Ministério da Defesa<br>Saúde → Ministério da Saúde | 3 | 3 | 6 |
| Constituição, Justiça e Cidadania - CCJ | Justiça e Defesa → Ministério da Justiça<br>Planejamento e Desenvolvimento Urbano → Ministério do Planejamento, Orçamento e Gestão<br>Poderes do Estado e Representação → Órgãos do Ministério Público; Órgãos do Poder Judiciário; Tribunal de Contas da União | 4 | 4 | 8 |
| Desenvolvimento Regional e Turismo - CDR | Fazenda, Desenvolvimento e Turismo → Ministério do Turismo<br>Integração Nacional e Meio Ambiente → Ministério da Integração Nacional<br>Planejamento e Desenvolvimento Urbano → Ministério das Cidades | 4 | 4 | 8 |
| Direitos Humanos e Legislação Participativa- CDH | Poderes do Estado e Representação → Órgãos do Ministério Público; Presidência da República | 3 | 3 | 6 |
| Educação, Cultura e Esporte- CE | Educação, Cultura, Ciência e Tecnologia e Esporte → Ministério da Ciência, Tecnologia e Inovação; Ministério da Cultura; Ministério da Educação; Ministério do Esporte | 4 | 4 | 8 |
| Meio Ambiente, Defesa do Consumidor e Fiscalização e Controle - CMA | Integração Nacional e Meio Ambiente → Ministério do Meio Ambiente<br>Poderes do Estado e Representação → Órgãos do Ministério Público; Tribunal de Contas da União | 4 | 4 | 8 |
| Relações Exteriores e Defesa Nacional - CRE | Justiça e Defesa → Ministério da Defesa<br>Poderes do Estado e Representação → Ministério das Relações Exteriores | 3 | 3 | 6 |
| Serviços de Infraestrutura-CI | Infraestrutura → Ministério das Comunicações; Ministério de Minas e Energia; Ministério dos Transportes<br>Poderes do Estado e Representação → Presidência da República | 4 | 4 | 8 |
| TOTAL | | 121 | 121 | 242 |