## ANEXO I

**ANEXO À RESOLUÇÃO DO CONGRESSO NACIONAL Nº 1, DE 2006-CN**

**Quantidade de emendas:** Apropriação, Remanejamento e Total.

| Comissão Permanente | Área temática | Subárea Temática | Apropriação | Remanejamento | Total |
|---|---|---|---:|---:|---:|
| CÂMARA DOS DEPUTADOS | | | 76 | 76 | 152 |
| Mesa Diretora | Poderes do Estado e Representação | Câmara dos Deputados | 4 | 4 | 8 |
| Agricultura, Pecuária, Abastecimento e Desenvolvimento Rural - CAPADR | Agricultura e Desenvolvimento Agrário<br>Integração Nacional e Meio Ambiente | Ministério da Agricultura, Pecuária e Abastecimento<br>Ministério da Pesca e Aquicultura<br>Ministério do Desenvolvimento Agrário<br>Ministério da Integração Nacional<br>Ministério do Meio Ambiente | 4 | 4 | 8 |
| Amazônia, Integração Nacional e Desenvolvimento Regional - CAINDR | Fazenda, Desenvolvimento e Turismo<br>Integração Nacional e Meio Ambiente<br>Justiça e Defesa | Ministério do Turismo<br>Ministério da Integração Nacional<br>Ministério do Meio Ambiente<br>Ministério da Justiça | 4 | 4 | 8 |
| Ciência e Tecnologia, Comunicação e Informática - CCTCI | Educação, Cultura, Ciência e Tecnologia e Esporte<br>Infraestrutura<br>Justiça e Defesa | Ministério da Ciência, Tecnologia e Inovação<br>Ministério das Comunicações<br>Ministério da Defesa | 4 | 4 | 8 |
| Constituição e Justiça e de Cidadania - CCJC | Justiça e Defesa<br>Poderes do Estado e Representação | Ministério da Justiça<br>Órgãos do Ministério Público<br>Órgãos do Poder Judiciário<br>Presidência da República | 4 | 4 | 8 |
| Defesa do Consumidor - CDC | Fazenda, Desenvolvimento e Turismo<br>Justiça e Defesa | Ministério da Fazenda<br>Ministério do Desenvolvimento, Indústria e Comércio Exterior<br>Ministério da Justiça | 4 | 4 | 8 |
| Desenvolvimento Econômico, Indústria e Comércio - CDEIC | Agricultura e Desenvolvimento Agrário<br>Fazenda, Desenvolvimento e Turismo | Ministério da Agricultura, Pecuária e Abastecimento<br>Ministério da Fazenda<br>Ministério do Desenvolvimento, Indústria e Comércio Exterior | 4 | 4 | 8 |
| Desenvolvimento Urbano - CDU | Integração Nacional e Meio Ambiente<br>Planejamento e Desenvolvimento Urbano | Ministério da Integração Nacional<br>Ministério do Meio Ambiente<br>Ministério das Cidades | 4 | 4 | 8 |
| Direitos Humanos e Minorias - CDHM | Justiça e Defesa<br>Poderes do Estado e Representação<br>Trabalho, Previdência e Assistência Social | Ministério da Justiça<br>Presidência da República<br>Ministério do Desenvolvimento Social e Combate à Fome | 4 | 4 | 8 |
| Educação-CE | Educação, Cultura, Ciência e Tecnologia e Esporte<br>Justiça e Defesa<br>Trabalho, Previdência e Assistência Social | Ministério da Educação<br>Ministério da Cultura<br>Ministério da Ciência, Tecnologia e Inovação<br>Ministério do Esporte<br>Ministério da Defesa<br>Ministério do Trabalho e Emprego | 3 | 3 | 6 |
| Cultura -CCULT | Educação, Cultura, Ciência e Tecnologia e Esporte<br>Justiça e Defesa | Ministério da Cultura<br>Ministério da Educação<br>Ministério da Ciência, Tecnologia e Inovação<br>Ministério do Esporte<br>Ministério da Justiça | 3 | 3 | 6 |
| Finanças e Tributação- CFT | Fazenda, Desenvolvimento e Turismo<br>Planejamento e Desenvolvimento Urbano | Ministério da Fazenda<br>Ministério do Planejamento, Orçamento e Gestão | 3 | 3 | 6 |
| Fiscalização Financeira e Controle - CFFC | Poderes do Estado e Representação | Ministério do Planejamento, Orçamento e Gestão<br>Presidência da República<br>Tribunal de Contas da União | 4 | 4 | 8 |
| Legislação Participativa - CLP | | | 0 | 0 | 0 |
| Meio Ambiente e Desenvolvimento Sustentável - CMADS | Educação, Cultura, Ciência e Tecnologia e Esporte<br>Integração Nacional e Meio Ambiente | Ministério da Ciência, Tecnologia e Inovação<br>Ministério do Meio Ambiente | 3 | 3 | 6 |
| Minas e Energia - CME | Educação, Cultura, Ciência e Tecnologia e Esporte<br>Infraestrutura<br>Integração Nacional e Meio Ambiente | Ministério da Ciência, Tecnologia e Inovação<br>Ministério de Minas e Energia<br>Ministério do Meio Ambiente | 4 | 4 | 8 |
| Relações Exteriores e de Defesa Nacional - CREDN | Justiça e Defesa<br>Poderes do Estado e Representação | Ministério da Defesa<br>Ministério das Relações Exteriores | 3 | 3 | 6 |
| Segurança Pública e Combate ao Crime Organizado - CSPCCO | Justiça e Defesa | Ministério da Justiça | 2 | 2 | 4 |
| Seguridade Social e Família - CSSF | Saúde<br>Trabalho, Previdência e Assistência Social | Ministério da Saúde<br>Ministério da Previdência Social<br>Ministério do Desenvolvimento Social e Combate à Fome | 4 | 4 | 8 |
| Trabalho, de Administração e Serviço Público - CTASP | Planejamento e Desenvolvimento Urbano<br>Trabalho, Previdência e Assistência Social | Ministério do Planejamento, Orçamento e Gestão<br>Ministério da Previdência Social<br>Ministério do Trabalho e Emprego | 4 | 4 | 8 |
| Turismo e Desporto - CTD | Educação, Cultura, Ciência e Tecnologia e Esporte<br>Fazenda, Desenvolvimento e Turismo | Ministério do Esporte<br>Ministério do Turismo | 3 | 3 | 6 |
| Viação e Transporte - CVT | Infraestrutura<br>Justiça e Defesa<br>Poderes do Estado e Representação | Ministério dos Transportes<br>Ministério da Defesa<br>Presidência da República | 4 | 4 | 8 |
| SENADO FEDERAL | | | 45 | 45 | 90 |
| Mesa Diretora | Poderes do Estado e Representação | Senado Federal | 4 | 4 | 8 |
| Agricultura e Reforma Agrária - CRA | Agricultura e Desenvolvimento Agrário<br>Integração Nacional e Meio Ambiente | Ministério da Agricultura, Pecuária e Abastecimento<br>Ministério da Pesca e Aquicultura<br>Ministério do Desenvolvimento Agrário<br>Ministério do Meio Ambiente | 4 | 4 | 8 |
| Assuntos Econômicos - CAE | Fazenda, Desenvolvimento e Turismo<br>Planejamento e Desenvolvimento Urbano | Ministério da Fazenda<br>Ministério do Desenvolvimento, Indústria e Comércio Exterior<br>Ministério do Planejamento, Orçamento e Gestão | 4 | 4 | 8 |
| Assuntos Sociais -CAS | Saúde<br>Trabalho, Previdência e Assistência Social | Ministério da Saúde<br>Ministério da Previdência Social<br>Ministério do Desenvolvimento Social e Combate à Fome | 4 | 4 | 8 |
| Ciência, Tecnologia, Inovação, Comunicação e Informática - CCT | Agricultura e Desenvolvimento Agrário<br>Educação, Cultura, Ciência e Tecnologia e Esporte<br>Infraestrutura<br>Justiça e Defesa<br>Saúde | Ministério da Agricultura, Pecuária e Abastecimento<br>Ministério da Ciência, Tecnologia e Inovação<br>Ministério da Educação<br>Ministério das Comunicações<br>Ministério da Defesa<br>Ministério da Saúde | 3 | 3 | 6 |
| Constituição, Justiça e Cidadania - CCJ | Justiça e Defesa<br>Planejamento e Desenvolvimento Urbano<br>Poderes do Estado e Representação | Ministério da Justiça<br>Ministério do Planejamento, Orçamento e Gestão<br>Órgãos do Ministério Público<br>Órgãos do Poder Judiciário<br>Tribunal de Contas da União | 4 | 4 | 8 |
| Desenvolvimento Regional e Turismo - CDR | Fazenda, Desenvolvimento e Turismo<br>Integração Nacional e Meio Ambiente<br>Planejamento e Desenvolvimento Urbano | Ministério do Turismo<br>Ministério da Integração Nacional<br>Ministério das Cidades | 4 | 4 | 8 |
| Direitos Humanos e Legislação Participativa- CDH | Poderes do Estado e Representação | Órgãos do Ministério Público<br>Presidência da República | 3 | 3 | 6 |
| Educação, Cultura e Esporte- CE | Educação, Cultura, Ciência e Tecnologia e Esporte | Ministério da Ciência, Tecnologia e Inovação<br>Ministério da Cultura<br>Ministério da Educação<br>Ministério do Esporte | 4 | 4 | 8 |
| Meio Ambiente, Defesa do Consumidor e Fiscalização e Controle - CMA | Integração Nacional e Meio Ambiente<br>Poderes do Estado e Representação | Ministério do Meio Ambiente<br>Órgãos do Ministério Público<br>Tribunal de Contas da União | 4 | 4 | 8 |
| Relações Exteriores e Defesa Nacional - CRE | Justiça e Defesa<br>Poderes do Estado e Representação | Ministério da Defesa<br>Ministério das Relações Exteriores | 3 | 3 | 6 |
| Serviços de Infraestrutura-CI | Infraestrutura<br>Poderes do Estado e Representação | Ministério das Comunicações<br>Ministério de Minas e Energia<br>Ministério dos Transportes<br>Presidência da República | 4 | 4 | 8 |
| TOTAL | | | 121 | 121 | 242 |